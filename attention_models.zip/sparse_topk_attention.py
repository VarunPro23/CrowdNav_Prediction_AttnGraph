import torch
import torch.nn as nn

class TopKAttention(nn.Module):
    """
    Sparse top-K attention: attends only to the K highest-scoring keys per query.
    """
    def __init__(self, k):
        super(TopKAttention, self).__init__()
        self.k = k

    def forward(self, query, key, value, mask=None):
        """
        Args:
            query, key: [batch, seq_len, dim]
            value: [batch, seq_len, dim]
            mask: optional BoolTensor [batch, seq_len], True for valid positions.
        Returns:
            context: [batch, seq_len, dim]
            weights: [batch, seq_len, seq_len] (zeros outside top-K)
        """
        scores = torch.matmul(query, key.transpose(-2,-1)) / (key.size(-1)**0.5)
        if mask is not None:
            scores = scores.masked_fill(~mask.unsqueeze(1), float('-inf'))
        topk_vals, topk_inds = torch.topk(scores, self.k, dim=-1)
        batch_size, seq_len, _ = scores.size()
        sparse_mask = torch.zeros_like(scores, dtype=torch.bool)
        for b in range(batch_size):
            for i in range(seq_len):
                sparse_mask[b, i, topk_inds[b, i]] = True
        sparse_scores = scores.masked_fill(~sparse_mask, float('-inf'))
        weights = torch.softmax(sparse_scores, dim=-1)
        context = torch.matmul(weights, value)
        return context, weights
