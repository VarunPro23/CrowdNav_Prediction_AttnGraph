import torch
import torch.nn as nn
import torch.nn.functional as F

class BahdanauAttention(nn.Module):
    """
    Additive (Bahdanau) attention mechanism.
    Computes attention weights between query and key, and returns context vector.
    """
    def __init__(self, query_dim, key_dim, attn_dim):
        super(BahdanauAttention, self).__init__()
        self.W_q = nn.Linear(query_dim, attn_dim, bias=False)
        self.W_k = nn.Linear(key_dim, attn_dim, bias=False)
        self.v = nn.Linear(attn_dim, 1, bias=False)

    def forward(self, query, key, value, mask=None):
        """
        Args:
            query: Tensor of shape [batch, seq_q, query_dim]
            key:   Tensor of shape [batch, seq_k, key_dim]
            value: Tensor of shape [batch, seq_k, value_dim]
            mask:  Optional BoolTensor of shape [batch, seq_q, seq_k], True for valid positions.
        Returns:
            context: Tensor of shape [batch, seq_q, value_dim]
            attn_weights: Tensor of shape [batch, seq_q, seq_k]
        """
        Q = self.W_q(query).unsqueeze(2)  # [batch, seq_q, 1, attn_dim]
        K = self.W_k(key).unsqueeze(1)    # [batch, 1, seq_k, attn_dim]
        scores = self.v(torch.tanh(Q + K)).squeeze(-1)  # [batch, seq_q, seq_k]
        if mask is not None:
            scores = scores.masked_fill(~mask, float('-inf'))
        weights = torch.softmax(scores, dim=-1)  # [batch, seq_q, seq_k]
        context = torch.bmm(weights, value)  # [batch, seq_q, value_dim]
        return context, weights
