import torch
from torch_geometric.nn import GATConv

class GATAttention(nn.Module):
    """
    Graph Attention Network layer using PyTorch Geometric.
    """
    def __init__(self, in_channels, out_channels, heads=1, concat=True, dropout=0.0):
        super(GATAttention, self).__init__()
        self.gat = GATConv(in_channels, out_channels, heads=heads,
                           concat=concat, dropout=dropout)

    def forward(self, x, edge_index):
        """
        Args:
            x: Node feature matrix of shape [num_nodes, in_channels]
            edge_index: Graph connectivity [2, num_edges]
        Returns:
            out: [num_nodes, heads*out_channels] if concat else [num_nodes, out_channels]
        """
        return self.gat(x, edge_index)
