import torch
import torch.nn as nn

class MultiHeadDotProductAttention(nn.Module):
    """
    Scaled multi-head dot-product attention.
    """
    def __init__(self, embed_dim, num_heads, dropout=0.0):
        super(MultiHeadDotProductAttention, self).__init__()
        assert embed_dim % num_heads == 0, "embed_dim must be divisible by num_heads"
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads

        self.q_proj = nn.Linear(embed_dim, embed_dim)
        self.k_proj = nn.Linear(embed_dim, embed_dim)
        self.v_proj = nn.Linear(embed_dim, embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, query, key, value, mask=None):
        """
        Args:
            query, key, value: [batch, seq_len, embed_dim]
            mask: optional BoolTensor [batch, seq_len, seq_len]
        Returns:
            output: [batch, seq_len, embed_dim]
            attn_weights: [batch, num_heads, seq_len, seq_len]
        """
        B, T, _ = query.size()
        Q = self.q_proj(query).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        K = self.k_proj(key).view(B, T, self.num_heads, self.head_dim).transpose(1,2)
        V = self.v_proj(value).view(B, T, self.num_heads, self.head_dim).transpose(1,2)

        scores = torch.matmul(Q, K.transpose(-2,-1)) / (self.head_dim ** 0.5)
        if mask is not None:
            scores = scores.masked_fill(~mask.unsqueeze(1), float('-inf'))
        weights = torch.softmax(scores, dim=-1)
        weights = self.dropout(weights)

        attn_output = torch.matmul(weights, V)
        attn_output = attn_output.transpose(1,2).contiguous().view(B, T, self.embed_dim)
        output = self.out_proj(attn_output)
        return output, weights
