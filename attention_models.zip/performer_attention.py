import torch
import torch.nn as nn
from performer_pytorch import Performer

class PerformerAttention(nn.Module):
    """
    Linear-time attention using Performer.
    """
    def __init__(self, dim, heads=8, causal=False):
        super(PerformerAttention, self).__init__()
        self.performer = Performer(dim=dim, depth=1, heads=heads, causal=causal)

    def forward(self, x):
        """
        Args:
            x: Input sequence [batch, seq_len, dim]
        Returns:
            out: [batch, seq_len, dim]
        """
        return self.performer(x)
